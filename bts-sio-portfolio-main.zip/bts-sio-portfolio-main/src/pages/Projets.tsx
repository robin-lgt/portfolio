import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FolderOpen, ExternalLink, Github } from "lucide-react";

const Projets = () => {
  // Structure de projet exemple - à personnaliser avec vos vrais projets
  const projets = [
    {
      id: 1,
      titre: "Projet à venir",
      description: "Les projets réalisés durant le BTS seront affichés ici.",
      technologies: ["À définir"],
      isPlaceholder: true,
    },
  ];

  return (
    <div className="min-h-screen container mx-auto px-4 py-16">
      <div className="max-w-6xl mx-auto animate-fade-in">
        {/* Header */}
        <div className="text-center mb-16 animate-slide-up">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            Mes Projets
          </h1>
          <p className="text-lg text-muted-foreground">
            Découvrez les projets réalisés durant ma formation en BTS SIO SISR
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {projets.map((projet, index) => (
            <Card
              key={projet.id}
              className="p-8 shadow-soft hover:shadow-hover transition-all duration-300 animate-slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {projet.isPlaceholder ? (
                <div className="text-center py-12">
                  <FolderOpen size={64} className="mx-auto mb-6 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-3">{projet.titre}</h3>
                  <p className="text-muted-foreground mb-6">{projet.description}</p>
                  <Badge variant="outline" className="text-sm">
                    En cours de développement
                  </Badge>
                </div>
              ) : (
                <>
                  <div className="aspect-video w-full bg-gradient-to-br from-primary/10 to-secondary/10 rounded-lg mb-6 flex items-center justify-center">
                    <FolderOpen size={48} className="text-muted-foreground" />
                  </div>
                  
                  <h3 className="text-xl font-bold mb-3">{projet.titre}</h3>
                  <p className="text-muted-foreground mb-4">{projet.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {projet.technologies.map((tech) => (
                      <Badge key={tech} variant="secondary" className="text-xs">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-3">
                    <Button size="sm" className="flex-1">
                      <ExternalLink size={16} className="mr-2" />
                      Voir le projet
                    </Button>
                    <Button size="sm" variant="outline">
                      <Github size={16} />
                    </Button>
                  </div>
                </>
              )}
            </Card>
          ))}
        </div>

        {/* Info Box */}
        <Card className="mt-12 p-8 bg-gradient-to-br from-primary/5 to-secondary/5 border-dashed animate-slide-up">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-3">À venir...</h3>
            <p className="text-muted-foreground">
              Cette section sera régulièrement mise à jour avec les nouveaux projets réalisés durant ma formation. 
              Revenez bientôt pour découvrir mes réalisations !
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Projets;
